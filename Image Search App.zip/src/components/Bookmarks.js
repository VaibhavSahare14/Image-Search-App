import React from 'react'

const Bookmarks = () => {
    return (
        <div>Bookmarks</div>
    )
}

export default Bookmarks