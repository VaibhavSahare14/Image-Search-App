import React from 'react'

const Mainpage = () => {

    return (
        <div className='top'>
            <h1>React Photo Search</h1>
            <button className='bookmarks'>Bookmarks</button>
        </div>
    )
}

export default Mainpage;